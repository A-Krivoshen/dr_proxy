=== Proxy Server Helper ===
Description: Настраивайте и используйте прокси-серверы с интерфейсом администратора.
Version: 1.4.2
Author: Aleksey Krivoshein aka Dr.Slon
Author URI: https://krivoshein.site
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.htm

Requires at least: 5.6
Tested up to:      6.4
Requires PHP:      7.2
Stable tag:        1.4.2

Proxy server helper for WordPress.

== Description ==

Allows you to quickly connect to proxy or proxyes servers.

== Installation ==

1. Upload `dr_proxy` to the `/wp-content/dr_proxy/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.